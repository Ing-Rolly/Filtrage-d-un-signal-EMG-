% Affichage: Etude temporelle et fr�quentielle
% Etude temporelle
emg = load('emg_healthy.txt'); % Chargement des donn�es
if size(emg, 2) ~= 2
	error('Le fichier emg_healthy.txt doit contenir exactement deux colonnes (temps et signal).');
end
figure(1);
plot(emg(:,1), emg(:,2)); grid on;
xlabel('Temps (s)');
ylabel('Amplitude (mV)');
title('Signal EMG brut');

% Etude fr�quentielle
Ts = emg(2,1) - emg(1,1); % Intervalle de temps entre deux mesures successives (0.25 ms)
Fs1 = 1/Ts; % Fr�quence d'�chantillonnage (devrait �tre 4000 Hz)
L = size(emg(:,1), 1); % Nombre de mesures
t = emg(:,1); % Vecteur temps
s = emg(:,2); % Vecteur tension

Y = fft(s); % Transform�e de Fourier
P2 = abs(Y)/L; % Normalisation par le nombre d'�chantillons
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);
f = Fs1*(0:(L/2))/L;
figure(2);
plot(f, P1); grid on;
xlabel('f (Hz)');
ylabel('EMG en V');
title('Signal fr�quentiel EMG');

% Filtrage du signal
% Calcul de filtre passe-bas (500 Hz)
Fs = 4000;
N = 40;
Fpass = 500; % Fr�quence de la bande passante
Fstop = 550; % Fr�quence de la bande d'arr�t
Wpass = 1; % Bande passante pr�serv�e sans traitement prioritaire
Wstop = 1; % Non amplification de la suppression des interf�rences
dens = 20; % Facteur de densit�

% Calcul des coefficients avec FIR1
b = fir1(N, [Fpass]/(Fs/2), 'low'); % Filtre passe-bas � 500 Hz
% Filtrer le signal
s_signal = emg(:,2); % Signal brut
x = filter(b, 1, s_signal); % Premier filtrage passe-bas

% Filtre notch � 50 Hz pour �liminer le bruit de ligne
Fnotch = 50; % Fr�quence du bruit de ligne
notch_low = (Fnotch - 1)/(Fs/2); % 49 Hz normalis�
notch_high = (Fnotch + 1)/(Fs/2); % 51 Hz normalis�
b_notch = fir1(N, [notch_low notch_high], 'stop'); % Filtre notch
x = filtfilt(b_notch, 1, x); % Appliquer le filtre notch

v = 2 * abs(x); % Redressement et multiplication par 2
figure(3);
plot(t, v); grid on;
xlabel('Temps (s)');
ylabel('EMG en V');
title('Signal EMG: Redressement fois 2');

% Filtre passe-bas � 6 Hz pour l'enveloppe
c = fir1(300, 6/(Fs/2), 'low'); % Filtre passe-bas � 6 Hz, ordre 300 pour un lissage optimal
x1 = filtfilt(c, 1, v); % Utilisation de filtfilt pour �viter le d�phasage
figure(4);
plot(t, x1); grid on;
xlabel('Temps (s)');
ylabel('EMG en V');
title('Signal EMG filtr� � 6 Hz (enveloppe)');
axis([-1 13 -0.05 0.6])